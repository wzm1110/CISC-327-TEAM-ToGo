import new_frontend
import back_end
import os


def run_frontend(day):
    os.system("new_frontend.py valid_accounts.txt transaction_summary_file" + day + "1.txt")
    print("-----------------1st daily file completed------------------------------------")
    os.system("new_frontend.py valid_accounts.txt transaction_summary_file" + day + "2.txt")
    print("-----------------2nd daily file completed------------------------------------")
    os.system("new_frontend.py valid_accounts.txt transaction_summary_file" + day + "3.txt")
    print("-----------------3rd daily file completed------------------------------------")




def merge_files(day,first, second, third):
    daily_merged = open("transaction_summary_file_"+day+"merged.txt",'w')
    f1 = open(first,'r')
    line1 = f1.readlines()


    f2 = open(second,'r')
    line2 = f2.readlines()

    f3 = open(third,'r')
    line3 = f3.readlines()

    todo = line1 + line2 + line3
    daily_merged.writelines(todo)

    f1.close()
    f2.close()
    f3.close()
    daily_merged.close()



def run_backend(day):
    os.system("back_end.py transaction_summary_file_"+day+"merged.txt master_accounts.txt valid_accounts.txt")

def main():
    run_frontend("MON")
    merge_files("MON", 'transaction_summary_fileMON1.txt', 'transaction_summary_fileMON2.txt', 'transaction_summary_fileMON3.txt')
    run_backend("MON")

    run_frontend("TUE")
    merge_files("TUE", 'transaction_summary_fileTUE1.txt', 'transaction_summary_fileTUE2.txt', 'transaction_summary_fileTUE3.txt')
    run_backend("TUE")

    run_frontend("WED")
    merge_files("WED", 'transaction_summary_fileWED1.txt', 'transaction_summary_fileWED2.txt', 'transaction_summary_fileWED3.txt')
    run_backend("WED")

    run_frontend("THU")
    merge_files("THU", 'transaction_summary_fileTHU1.txt', 'transaction_summary_fileTHU2.txt', 'transaction_summary_fileTHU3.txt')
    run_backend("THU")

    run_frontend("FRI")
    merge_files("FRI", 'transaction_summary_fileFRI1.txt', 'transaction_summary_fileFRI2.txt', 'transaction_summary_fileFRI3.txt')
    run_backend("FRI")

main()
import back_end
import time
import sys

def main():
    file2 = sys.argv[2]
    file1 = sys.argv[1]
    test_case_1 = back_end.makeDecision([["1357989","000","yewin","\n"]],[["NEW","1234567","$0.0","0000000","yewin","\n"]])
    print("Testing case Number 1...")
    time.sleep(1)
    if test_case_1 == [['1234567', ' 000 ', 'yewin', '\n']]:
        print("Testing case Number 1 passed\n")
    else:
        print("Test failed")

    test_case_2 = back_end.makeDecision([["1356789", "000", "yewin",'\n']],  [["WDR","1234567","$1000.0","0000000","***",'\n']])
    print("Testing case Number 2...")
    time.sleep(1)
    if test_case_2 == []:
        print("Testing case Number 2 passed\n")
    else:
        print("Test failed\n")

    test_case_3 = back_end.makeDecision([["1234567", "000", "yewin",'\n']], [["WDR","1234567","$1000.0","0000000","***",'\n']])
    print("Testing case Number 3...")
    time.sleep(1)
    if test_case_3 == []:
        print("Testing case Number 3 passed\n")
    else:
        print("Test failed")

    test_case_4 = back_end.makeDecision([["1234567", " 200000 ", "yewin",'\n']],  [["WDR","1234567","$10.0","0000000","***",'\n']])
    print("Testing case Number 4...")
    time.sleep(1)
    if test_case_4 == [['1234567',' 199000 ','\n']]:
        print("Testing case Number 4 passed\n")
    else:
        print("Test failed")

main()
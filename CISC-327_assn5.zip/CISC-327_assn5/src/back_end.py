import new_frontend
import sys
import os
def main():
    #transactions = []
    file = new_frontend.fileOpen(sys.argv[1])
    file2 = new_frontend.fileOpen(sys.argv[2])
    transactions = makeList(file)
    accounts = makeList(file2)
    makeDecision(accounts, transactions)
    content = new_frontend.fileOpen(sys.argv[2])
    #valid = sys.argv[3]
    #writeValidAccounts(valid,content)
    #process


def makeList(file):
    new = []
    for line in file:
        if line != "EOS":
            new.append(line.split(" "))
    return new


def makeDecision(mast,list):
    user_info = {}
    for user in mast:
        user_info[user[0]] = int(user[1])
    f = open(sys.argv[2], "w")
    todo = []
    #-----------------------------------------------------
    for i in range(len(list)):
        if list[i][0] == "NEW": #accounts not in valid list
            todo.append([list[i][1], " 000 ", list[i][-1], '\n'])
            user_info[list[i][1]] = 0


        elif list[i][0] == "DEL":
            for j in range(len(todo)):
                if list[i][1] in todo[j] and user_info[list[i][1]] == "0":
                    todo.remove(todo[j])
                    del user_info[list[i][1]]

                    print("successful delete")
                elif list[i][1] not in todo[j]:
                    pass
                else:
                    print("cannot delete")
    #-----------------------------------------------------------
        elif list[i][0] == "DEP":
            for user1, balance in user_info.items():
                if list[i][1] == user1:
                    read_val = int(list[i][2][1:-2]) * 100
                    user_info[user1] += read_val

        elif list[i][0] == "WDR":
            for user2, balance1 in user_info.items():
                if list[i][1] == user2:
                    read_val1 = int(list[i][2][1:-2]) * 100
                    if user_info[user2] - read_val1 >= 0:
                        user_info[user2] -= read_val1
                        todo.append([list[i][1], user_info[user2], list[i][-1]])

                    else:
                        print("not enough balance")
                else:
                    print("user not found")

        elif list[i][0] == "XFR":
            for user3, balance1 in user_info.items():
                if list[i][1] == user3:
                    read_val2 = int(list[i][2][1:-2])
                    if user_info[list[i][-2]] - read_val2 >= 0:
                        user_info[list[i][-2]] -= read_val2
                        user_info[list[i][1]] += read_val2
                    else:
                        print("not enough balance")

    todo.sort(reverse=True) #IN DESENDING ORDER
    for x in range(len(todo)):
        if checkMaxLen(todo[x]) :
            pass
        else:
            print("ERROR length")
    for k in range(len(todo)):
        for key, val in user_info.items():
            if todo[k][0] == key:
                todo[k][1] = " " + str(val) + " "
        for word in todo[k]:

            f.write(word)

    f.close()
    return todo


def checkMaxLen(list):
    if len(list) > 47:
        return False
    else:
        return True

def writeValidAccounts(file,content):
    todo = makeList(content)
    f = open(file,"w")
    for line in todo:
        f.write(line[0])
        f.write('\n')
    f.write('0000000')
    f.close()

main()


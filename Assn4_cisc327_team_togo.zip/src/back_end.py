import new_frontend
import sys
import os
def main():
    # main() funcion accept old master account file
    # and transaction summary file as input and return one
    # new master account file and one new valid accounts file.
    file = new_frontend.fileOpen(sys.argv[1])
    file2 = new_frontend.fileOpen(sys.argv[2])
    transactions = makeList(file)
    accounts = makeList(file2)
    makeDecision(accounts, transactions)
    content = new_frontend.fileOpen(sys.argv[2])


# makeList(0 is a helper function that take file as input and return a list as output
def makeList(file):
    new = []
    for line in file:
        if line != "EOS":
            new.append(line.split(" "))
    return new

#makeDecision() take 2 lists as input and it will enter
# different operation and do modification to the master account file on buffer.
#finally it will update a new master_account file and new valid account file

def makeDecision(mast,list):
    user_info = {}
    for user in mast:
        user_info[user[0]] = [int(user[1]), user[2]]
    f = open(sys.argv[2], "w")
    todo = []
    #-----------------------------------------------------
    for i in range(len(list)):
        if list[i][0] == "NEW": #accounts not in valid list
            todo.append([list[i][1], " 000 ", list[i][-1], '\n'])
            user_info[list[i][1]] = 0


        elif list[i][0] == "DEL":
            for j in range(len(todo)):
                if list[i][1] in todo[j] and user_info[list[i][1]] == "0":
                    todo.remove(todo[j])
                    del user_info[list[i][1]]

                    print("successful delete")
                elif list[i][1] not in todo[j]:
                    pass
                else:
                    print("cannot delete")
    #-----------------------------------------------------------
        elif list[i][0] == "DEP":
            for user1, balance in user_info.items():
                if list[i][1] == user1:
                    read_val = int(float(list[i][2][1:])*100)
                    user_info[user1][0] += read_val

        elif list[i][0] == "WDR":
            for user2, balance1 in user_info.items():
                if list[i][1] == user2:
                    read_val1 = int(float(list[i][2][1:])*100)
                    print(read_val1)
                    if user_info[user2][0] - read_val1 >= 0:
                        print(user_info[user2][0])
                        user_info[user2][0] -= read_val1
                        print("successfully withdrawn")
                        todo.append([list[i][1], user_info[user2][0], user_info[user2][1],'\n'])

                    else:
                        print("not enough balance")
                else:
                    print("user not found")


        elif list[i][0] == "XFR":
            for user3, balance1 in user_info.items():
                if list[i][1] == user3:
                    read_val2 = int(list[i][2][1:-2])
                    if user_info[list[i][-2]][0] - read_val2 >= 0:
                        user_info[list[i][-2]][0] -= read_val2
                        user_info[list[i][1]][0] += read_val2
                    else:
                        print("not enough balance")

    todo.sort(reverse=True) #IN DESENDING ORDER
    for x in range(len(todo)):
        if checkMaxLen(todo[x]) :
            pass
        else:
            print("ERROR length")
    for k in range(len(todo)):
        for key, val in user_info.items():
            if todo[k][0] == key:
                todo[k][1] = " " + str(val[0]) + " "
        for word in todo[k]:

            f.write(word)

    f.close()
    return todo

#checkMaxLen() is a helper funciton that help us check the maximum length of each line in the file
def checkMaxLen(list):
    if len(list) > 47:
        return False
    else:
        return True

#writeValidAccounts() is a helper functin that helkp us update the new valid accounts file
def writeValidAccounts(file,content):
    todo = makeList(content)
    f = open(file,"w")
    for line in todo:
        f.write(line[0])
        f.write('\n')
    f.write('0000000')
    f.close()

main()

